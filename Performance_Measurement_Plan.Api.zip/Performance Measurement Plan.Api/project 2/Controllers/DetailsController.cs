﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project_2.Models;

namespace project_2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetailsController : ControllerBase
    {
        private readonly MyDbContext Dbcontext;

        public DetailsController(MyDbContext Dbcontext)
        {
            this.Dbcontext = Dbcontext;
        }

        // POST: api/Details
        [HttpPost]
        public async Task<ActionResult<Details>> PostDetail(DetailsDTO detailsDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var detail = new Details
            {
               empname = detailsDTO.empname,
                mngname = detailsDTO.mngname,
                role = detailsDTO.role,
                duration = detailsDTO.duration,
                subdate = detailsDTO.subdate,  
                goals = detailsDTO.goals,
                expectations= detailsDTO.expectations,
                achievements = detailsDTO.achievements,
                remarks = detailsDTO.remarks,
                CreatedOn = DateTime.Now
            };

            Dbcontext.Details.Add(detail);
            await Dbcontext.SaveChangesAsync();

            return CreatedAtAction(nameof(PostDetail), new { id = detail.id }, detail);
        }

        // GET: api/Details
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Details>>> GetDetails()
        {
            return await Dbcontext.Details.ToListAsync(); 
        }
    }
}
