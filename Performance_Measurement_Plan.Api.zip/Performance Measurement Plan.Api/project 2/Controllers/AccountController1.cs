﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project_2.Entities;
using project_2.Models;
namespace project_2.Controllers
{
    public class AccountController1 : Controller
    {
        private readonly MyDbContext _context;

        public AccountController1(MyDbContext myDbContext)
        {
            _context = myDbContext;
        }
        public IActionResult Index()
        {
            return View(_context.UserAccounts);
        }

        public IActionResult Registration1()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Registration1(Registration model)
        {
            if (ModelState.IsValid)
            {
                UserAccount account = new UserAccount();
                account.username = model.username;
                account.Firstname = model.Firstname;
                account.Lastname = model.Lastname;
                account.password = model.password;

                try
                {
                    _context.UserAccounts.Add(account);
                    _context.SaveChanges();

                    ModelState.Clear();
                    ViewBag.Message = $"{account.Firstname} {account.Lastname} Registered SuccessFully. Please Login";
                }
                catch (DbUpdateException ex )
                {

                    ModelState.AddModelError("", "Please Enter unique Email or Password");
                    return View(model);
                }

                return View();  
            }
            return View(model);
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginAccount model)
        {
            if (ModelState.IsValid) {
                var user = _context.UserAccounts.Where(x => x.username == model.username && x.password == model.password).FirstOrDefault();
                if (user != null) {
                    //success
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, model.username),
                        new Claim("Name" , user.Firstname),
                        new Claim(ClaimTypes.Role , "User")
                    };

                    var ClaimsIdentity = new ClaimsIdentity(claims , CookieAuthenticationDefaults.AuthenticationScheme);
                    HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(ClaimsIdentity));

                    return RedirectToAction("SecurePage");
                 }
                else
                {
                    ModelState.AddModelError("", "Username or Password is not correct ");
                }
            }
            return View(model);
        }

        public IActionResult LogOut() {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index");
        }
        [Authorize]
        public IActionResult SecurePage()
        {
            ViewBag.Name = HttpContext.User.Identity.Name;
            return View();
        }
    }
}
