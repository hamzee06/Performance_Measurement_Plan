﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project_2.Models;

namespace project_2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly MyDbContext dbContext;
        public UsersController(MyDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpPost]
        [Route("Registration")]

        public IActionResult Registration(UserDTO userDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var objUser = dbContext.Users.FirstOrDefault(x => x.username == userDTO.username);
            if (objUser == null)
            {
                dbContext.Users.Add(new Users
                {
                    //UserId = Guid.NewGuid(),
                    username = userDTO.username,
                    password = userDTO.password,
                    empname = userDTO.empname,
                    mngname = userDTO.mngname,
                    role = userDTO.role,
                });
                dbContext.SaveChanges();
                return Ok("User Registered Successfully");
            }
            else
            {
                return BadRequest("User Already exists with same username" );
            }
        }

        [HttpPost]
        [Route("Login")]

        public IActionResult Login(LogInDTO logInDTO)
        {
            var user = dbContext.Users.FirstOrDefault(x => x.username == logInDTO.username && x.password == logInDTO.password);

            if (user != null)
            {
                return Ok(user);
            }

            else
            {
                return NoContent();
            }
        }

        [HttpGet]
        [Route("GetUsers")]

        public IActionResult GetUsers()
        {
            return Ok(dbContext.Users.ToList());
        }

        [HttpGet]
        [Route("GetUser/{id}")]
        public IActionResult GetUser(Guid id)
        {
            var res = dbContext.Users.FirstOrDefault(x => x.UserId == id);
            if (res != null)
            {
                UserDTO user = new UserDTO();
                user.UserId = res.UserId;

                user.empname = res.empname;
                user.role = res.role;
                user.username = res.username;
                user.mngname = res.mngname;

                return Ok(user);
            }
            else
                return NoContent();
        }


    }

}
    


