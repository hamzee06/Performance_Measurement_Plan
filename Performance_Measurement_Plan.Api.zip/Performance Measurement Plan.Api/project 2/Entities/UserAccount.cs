﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace project_2.Entities
{
    [Index(nameof(username), IsUnique = true)]
    [Index(nameof(password) , IsUnique = true)]
    public class UserAccount
    {
        [Key]
        public int id { get; set; }
        [Required(ErrorMessage ="First Name is Required")]
        [MaxLength(100 , ErrorMessage ="Max 100 characters allowed")]

        public string Firstname { get; set; }

        [Required(ErrorMessage = "Last Name is Required")]
        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]
        public string Lastname { get; set; }

        [Required(ErrorMessage = "Username is Required")]
        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]
      
        public string username { get; set; }

        [Required(ErrorMessage = "Password is Required")]
       
        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]
        public string password { get; set; }
        public int isActive { get; set; } = 1;

        public DateTime CreatedOn { get; set; } = DateTime.Now;
    }
}
