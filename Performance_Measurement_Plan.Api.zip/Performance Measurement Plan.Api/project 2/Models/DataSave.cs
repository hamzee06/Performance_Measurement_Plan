﻿namespace project_2.Models
{
    public class DataSave
    {
        public int ID { get; set; }
        public string empname { get; set; }

        public string mngname { get; set; }

        public string role { get; set; }
    }
}
