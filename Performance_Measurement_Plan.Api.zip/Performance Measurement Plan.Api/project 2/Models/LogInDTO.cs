﻿namespace project_2.Models
{
    public class LogInDTO
    {
        public string username { get; set; }

        public string password { get; set; }
    }
}
