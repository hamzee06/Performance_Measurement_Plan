﻿namespace project_2.Models
{
    public class UserDTO
    {
        public Guid UserId { get; set; }
        public string username { get; set; }

        public string password { get; set; }

        public string empname { get; set; }

        public string mngname { get; set; }

        public string role { get; set; }



    }
}
