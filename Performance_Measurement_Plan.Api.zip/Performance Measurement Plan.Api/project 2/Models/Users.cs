﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity;

namespace project_2.Models
{
    public class Users
    {
        public Guid UserId { get; set; }
        public string username { get; set; }

        public string password { get; set; }
        public string empname { get; set; }

        public string mngname { get; set; }

        public string role { get; set; }

        public int isActive { get; set; } = 1;

        public DateTime CreatedOn { get; set; } = DateTime.Now;

    }
}
