﻿namespace project_2.Models
{
    public class Details
    {
        public int id { get; set; }
        public string empname { get; set; }

        public string mngname { get; set; }

        public string role { get; set; }

        public string duration { get; set; }

        public string subdate { get; set; }
        public string goals { get; set; }

        public string expectations { get; set; }

        public string achievements { get; set; }

        public string remarks { get; set; }


        public DateTime CreatedOn { get; set; } = DateTime.Now;

    }
}
