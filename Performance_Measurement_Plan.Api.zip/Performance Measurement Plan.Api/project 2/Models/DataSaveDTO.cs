﻿namespace project_2.Models
{
    public class DataSaveDTO
    {
        public int ID { get; set; }
        public string empname { get; set; }

        public string mngname { get; set; }

        public string role { get; set; }

    }
}
