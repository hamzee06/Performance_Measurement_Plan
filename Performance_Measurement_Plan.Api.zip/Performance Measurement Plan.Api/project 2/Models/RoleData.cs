﻿using Microsoft.AspNetCore.Identity;

namespace project_2.Models
{
    public static class RoleData
    {
        public static async Task Initialize(RoleManager<IdentityRole<Guid>> roleManager)
        {
            string[] roleNames = { "Employee", "Manager" };

            foreach (var roleName in roleNames)
            {
                var roleExist = await roleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    await roleManager.CreateAsync(new IdentityRole<Guid> { Name = roleName });


                }
            }
        }
    }
}
