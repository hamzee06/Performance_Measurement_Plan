﻿using System.ComponentModel.DataAnnotations;
using System.Data.Common;
using Microsoft.SqlServer.Server;

namespace project_2.Models
{
    public class Registration
    {
        [Required(ErrorMessage = "First Name is Required")]
        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]

        public string Firstname { get; set; }

        [Required(ErrorMessage = "Last Name is Required")]
        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]
        public string Lastname { get; set; }

        [Required(ErrorMessage = "Username is Required")]
        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]
       // [EmailAddress(ErrorMessage = "Enter Valid Email Address")]
        

        public string username { get; set; }
       

        [Required(ErrorMessage = "Password is Required")]
        [DataType(DataType.Password)]
        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]
        public string password { get; set; }

        [Compare("Password" , ErrorMessage ="Please confirm Password")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}
