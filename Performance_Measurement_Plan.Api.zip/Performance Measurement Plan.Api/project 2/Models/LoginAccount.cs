﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace project_2.Models
{
    public class LoginAccount
    {
        [Required(ErrorMessage = "Username is Required")]
        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]
        [DisplayName("Username or Email ")]

        public string username { get; set; }

        [Required(ErrorMessage = "Password is Required")]

        [MaxLength(100, ErrorMessage = "Max 100 characters allowed")]
        public string password { get; set; }
    }
}
