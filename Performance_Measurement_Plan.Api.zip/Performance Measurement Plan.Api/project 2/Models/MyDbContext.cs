﻿using Microsoft.EntityFrameworkCore;
using project_2.Entities;

namespace project_2.Models
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Users>().HasKey(k => k.UserId);

            modelBuilder.Entity<Details>().HasKey(K => K.id);

            modelBuilder.Entity<DataSave>().HasKey(k => k.ID);
        }
        public DbSet<Users> Users {get; set;}

        public DbSet<Details> Details { get; set; }

        public DbSet<DataSave> DataSaves { get; set; }

        public DbSet<UserAccount> UserAccounts {get; set;}
    }
}
